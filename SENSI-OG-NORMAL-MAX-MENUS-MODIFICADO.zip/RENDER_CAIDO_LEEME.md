# Tu API en Render está CAÍDA

Al probar https://sensi-og-keys.onrender.com el propio Render responde:
`x-render-routing: no-server` (HTTP 404)

Eso significa que el servicio ya no existe o está apagado.

## Para que revocar y 1 dispositivo funcionen otra vez:

1. Entra a https://dashboard.render.com
2. Crea un **nuevo Web Service** (Node)
3. Conecta este repo o sube la carpeta `render-server`
4. Root directory: `render-server`
5. Start command: `node server.js`
6. Variables:
   - `DATABASE_URL` = tu Postgres de Render
   - `ADMIN_KEY` = una clave secreta tuya
7. Copia la URL nueva (ej: https://sensi-jpf-xxxx.onrender.com)
8. Pon esa URL en:
   - `ThreeOneOSFive/Info.plist` → `PantherAPIBaseURL`
   - Panel SENSI_JPF_API_Key.html → campo URL API
9. Redeploy / reinstala el IPA

Mientras el servidor esté caído la app acepta keys en **modo local** (firma válida), pero sin control multi-dispositivo ni revocación online.
