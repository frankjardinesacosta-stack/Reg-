# SENSI OG — Keys portables integradas

## Qué se hizo

El ZIP ahora **solo acepta keys generadas por el panel** `SENSI_OG_API_Key.html` (formato `OG-XXXXXX-XXXXXX-X-XXXXXX`).

### 1. App iOS (`ThreeOneOSFive/App.swift`)
- Valida las keys `OG-...` **localmente** con el mismo algoritmo FNV-1a del generador HTML.
- Comprueba firma, fecha de expiración y formato.
- Si la key es válida → acceso inmediato (rol `patches`) sin necesidad de servidor.
- Si la key no es del formato OG- o la firma no coincide → se rechaza.
- El catálogo de patches remoto se intenta cargar si el servidor está publicado; si no, la key sigue funcionando.

### 2. Panel generador
- El archivo `render-server/keys.html` es ahora el panel que tú proporcionaste.
- Genera keys con el formato:
  ```
  OG-{id}-{expBase36}-{dispositivos}-{firma}
  ```
- La firma se calcula con: `hash(id + "." + expMs + "." + devices + ".SENSI-OG-CORE-2026")`

### 3. Servidor (`render-server/server.js`)
- También acepta y valida las mismas keys portables `OG-...`.
- Cuando despliegues en Render, las keys generadas por el panel funcionarán tanto offline (app) como online (servidor).

## Cómo usar

1. Abre `render-server/keys.html` en el navegador (o sírvelo desde el servidor en `/keys`).
2. Genera una key con la duración y dispositivos que quieras.
3. En la app (calculadora → secuencia 052009) pega la key `OG-...`.
4. La app la valida al instante y da acceso.

## Importante
- Solo keys generadas por este panel funcionan.
- No se aceptan keys inventadas ni del sistema anterior.
- La key de prueba antigua `SENSI-OG-2026` ya no existe.
- Para catálogo y descarga de patches remotos sigue haciendo falta desplegar el servidor en Render.
