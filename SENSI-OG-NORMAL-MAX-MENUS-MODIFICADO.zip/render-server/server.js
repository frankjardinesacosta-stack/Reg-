import http from 'node:http';
import crypto from 'node:crypto';
import pg from 'pg';
const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false } });
const headers = {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'GET,POST,OPTIONS'};
const json=(data,status=200,extra={})=>({status,headers:{...headers,...extra},body:JSON.stringify(data)});
const day=86400000;
const digest=async s=>crypto.createHash('sha256').update(s).digest('hex');
const randomKey=()=> 'sensi-og-'+crypto.randomBytes(5).toString('hex').toUpperCase();

function fnv1a32(str) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h.toString(16).padStart(8, "0");
}
function validatePortableOG(key) {
  const parts = key.split("-");
  if (parts.length !== 5) return null;
  const prefix = (parts[0] || "").toUpperCase();
  const id = (parts[1] || "").toUpperCase();
  const expB36 = parts[2];
  const devices = parseInt(parts[3], 10);
  const sig = (parts[4] || "").toUpperCase();
  if (!/^[A-Z0-9]{3,16}$/.test(prefix) || !/^[A-Z0-9]{5}$/.test(id)) return null;
  if (!expB36 || !Number.isFinite(devices) || devices < 1 || devices > 50) return null;
  let expMs;
  try { expMs = parseInt(expB36, 36); } catch { return null; }
  if (!Number.isFinite(expMs) || expMs <= 0) return null;
  if (Date.now() >= expMs) return { error: "expired" };
  const payload = prefix + "." + id + "." + expMs + "." + devices + ".SENSI-JPF-CORE-2026";
  const expected = fnv1a32(payload).slice(0, 6).toUpperCase();
  if (sig !== expected) return { error: "invalid_key" };
  return { ok: true, expires_at: new Date(expMs).toISOString(), max_devices: devices };
}

function sql(q){return q.replace(/\?/g,()=>`$${(sql.i=(sql.i||0)+1)}`).replace(/^\s*INSERT OR IGNORE INTO/i,'INSERT INTO').replace(/;?\s*$/,'');}
class Statement { constructor(q){this.q=q;this.args=[]} bind(...a){this.args=a;return this} async first(){const r=await pool.query(sql(this.q),this.args);return r.rows[0]||null} async all(){const r=await pool.query(sql(this.q),this.args);return {results:r.rows}} async run(){const q=sql(this.q);const r=await pool.query(q,/^\s*INSERT INTO/i.test(q)?[...this.args]:this.args);return {meta:{changes:r.rowCount||0}}} }
const DB={prepare:q=>{sql.i=0;return new Statement(q)}};
async function init(){await pool.query(`CREATE TABLE IF NOT EXISTS license_keys (key TEXT PRIMARY KEY, device TEXT, activated_at TEXT, devices JSONB NOT NULL DEFAULT '[]'::jsonb, max_devices INTEGER NOT NULL DEFAULT 1, duration_ms BIGINT NOT NULL DEFAULT 2592000000, revoked BOOLEAN NOT NULL DEFAULT FALSE); CREATE TABLE IF NOT EXISTS patches (id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 1); CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, expires_at BIGINT NOT NULL); CREATE INDEX IF NOT EXISTS idx_keys_activation ON license_keys(activated_at);`); await pool.query(`ALTER TABLE license_keys ADD COLUMN IF NOT EXISTS devices JSONB NOT NULL DEFAULT '[]'::jsonb; ALTER TABLE license_keys ADD COLUMN IF NOT EXISTS max_devices INTEGER NOT NULL DEFAULT 1; ALTER TABLE license_keys ADD COLUMN IF NOT EXISTS duration_ms BIGINT NOT NULL DEFAULT 2592000000; ALTER TABLE license_keys ADD COLUMN IF NOT EXISTS revoked BOOLEAN NOT NULL DEFAULT FALSE; ALTER TABLE license_keys ADD COLUMN IF NOT EXISTS is_permanent BOOLEAN NOT NULL DEFAULT FALSE; ALTER TABLE license_keys ADD COLUMN IF NOT EXISTS force_expires_at BIGINT;`)}
async function session(req){const token=/panther_session=([^;]+)/.exec(req.headers.cookie||'')?.[1];if(!token)return false;const r=await pool.query('SELECT expires_at FROM sessions WHERE token_hash=$1',[await digest(token)]);return !!r.rows[0]&&Number(r.rows[0].expires_at)>Date.now()}
async function telegram(method,payload){const token=process.env.TELEGRAM_BOT_TOKEN;if(!token)throw Error('Telegram no configurado');const r=await fetch(`https://api.telegram.org/bot${token}/${method}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});const d=await r.json();if(!r.ok||!d.ok)throw Error('Telegram API error');return d.result}
const sendTelegram=(id,text)=>telegram('sendMessage',{chat_id:id,text,disable_web_page_preview:true});
async function makeKeys(count, durationMs=30*day, maxDevices=1, isPermanent=false){const keys=[];let tries=0;while(keys.length<count&&tries++<count*30){const key=randomKey();const r=await pool.query('INSERT INTO license_keys(key,duration_ms,max_devices,is_permanent) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING',[key,isPermanent?0:durationMs,maxDevices,!!isPermanent]);if(r.rowCount)keys.push(key)}if(keys.length!==count)throw Error('No se pudieron generar todas las Keys');return keys}
async function handleTelegram(req,res){if(!process.env.TELEGRAM_BOT_TOKEN||!process.env.TELEGRAM_ADMIN_ID||!process.env.TELEGRAM_WEBHOOK_SECRET)return json({error:'telegram not configured'},503);if(req.headers['x-telegram-bot-api-secret-token']!==process.env.TELEGRAM_WEBHOOK_SECRET)return json({error:'forbidden'},403);let update;try{update=JSON.parse(await readBody(req))}catch{return json({error:'invalid JSON'},400)}const msg=update.message;if(!msg?.chat||!msg?.from)return json({ok:true});const chat=String(msg.chat.id),uid=String(msg.from.id),admin=uid===String(process.env.TELEGRAM_ADMIN_ID);const raw=String(msg.text||'').trim();if(!raw.startsWith('/'))return json({ok:true});const [command,...args]=raw.split(/\s+/);const cmd=command.split('@')[0].toLowerCase();if(cmd==='/start'||cmd==='/help'){await sendTelegram(chat,admin?'Panel SENSI OG listo.\n/gen 1 — Key 30 días.\n/genperm 1 — Key PERMANENTE.\n/paid ID_TELEGRAM — entregar tras pago.\n/status — resumen.':'Bienvenido a SENSI OG. Debes comprar una Key. No se entrega ninguna antes de confirmar el pago.');return json({ok:true})}if(cmd==='/key'||cmd==='/buy'){await sendTelegram(chat,admin?'Usa /gen 1 para generar tu Key.':'Para recibir una Key debes comprar acceso. Contacta al administrador.');return json({ok:true})}if(!admin){await sendTelegram(chat,'No tienes permiso para administrar Keys. Para comprar acceso, contacta al administrador.');return json({ok:true})}if(cmd==='/gen'){const perm=String(args[0]||'').toLowerCase()==='perm'||String(args[0]||'').toLowerCase()==='permanent'||String(args[0]||'').toLowerCase()==='permanente';const n=Number(perm?(args[1]||1):(args[0]||1));if(!Number.isInteger(n)||n<1||n>25){await sendTelegram(chat,'Uso:\n/gen 1 — key 30 días\n/gen perm 1 — key PERMANENTE\n/genperm 1 — key PERMANENTE');return json({ok:true})}const keys=await makeKeys(n,30*day,1,perm);await sendTelegram(chat,perm?`Se generaron ${keys.length} Key(s) PERMANENTE(S):\n\n${keys.join('\n')}\n\nNo caducan. Se vinculan a un dispositivo.`:`Se generaron ${keys.length} Key(s):\n\n${keys.join('\n')}\n\nCada Key dura 30 días desde su primera activación y se vincula a un dispositivo.`);return json({ok:true})}if(cmd==='/genperm'||cmd==='/genpermanente'){const n=Number(args[0]||1);if(!Number.isInteger(n)||n<1||n>25){await sendTelegram(chat,'Uso: /genperm 1 (máximo 25).');return json({ok:true})}const keys=await makeKeys(n,30*day,1,true);await sendTelegram(chat,`Se generaron ${keys.length} Key(s) PERMANENTE(S):\n\n${keys.join('\n')}\n\nNo caducan. Se vinculan a un dispositivo.`);return json({ok:true})}if(cmd==='/paid'){const target=args[0];if(!target||!/^[0-9]{5,20}$/.test(target)){await sendTelegram(chat,'Uso: /paid ID_TELEGRAM. Confirma el pago antes de usarlo.');return json({ok:true})}const [key]=await makeKeys(1);try{await sendTelegram(target,`Pago confirmado. Tu Key SENSI OG:\n\n${key}\n\nNo la compartas. Dura 30 días desde su activación.`);await sendTelegram(chat,`Key entregada a ${target}.`)}catch{await sendTelegram(chat,`No se pudo enviar automáticamente. Entrega esta Key manualmente: ${key}`)}return json({ok:true})}if(cmd==='/status'){const r=await pool.query('SELECT COUNT(*) total, SUM(CASE WHEN device IS NULL THEN 1 ELSE 0 END) unused FROM license_keys');await sendTelegram(chat,`Keys registradas: ${r.rows[0].total||0}\nSin activar: ${r.rows[0].unused||0}`);return json({ok:true})}await sendTelegram(chat,'Comandos: /gen 1, /genperm 1, /paid ID_TELEGRAM, /status.');return json({ok:true})}
function readBody(req){return new Promise((resolve,reject)=>{let b='';req.on('data',c=>{b+=c;if(b.length>65536)reject(Error('too large'))});req.on('end',()=>resolve(b));req.on('error',reject)})}
async function serveKeysPage(){const fs=await import('node:fs/promises');const html=await fs.readFile(new URL('./keys.html',import.meta.url),'utf8');return {status:200,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'},body:html}}
async function handle(req){const u=new URL(req.url,'http://localhost'),path=u.pathname;if(req.method==='OPTIONS')return {status:204,headers:{...headers},body:''};if(path==='/health')return json({ok:true,service:'SENSI OG Render',database:!!process.env.DATABASE_URL});

if(path==='/telegram/webhook'&&req.method==='POST')return handleTelegram(req);if((path==='/'||path==='/keys')&&req.method==='GET')return await serveKeysPage();if(path==='/'&&req.method==='GET')return {status:200,headers:{'Content-Type':'text/html; charset=utf-8'},body:'<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>SENSI OG</title><body style="background:#080b13;color:white;font:18px system-ui;padding:3rem"><h1>SENSI OG · Servidor de Keys</h1><p>Servidor en línea.</p><p><a style="color:#8af" href="/health">Comprobar estado</a></p></body></html>'};
if(path==='/admin/state'&&req.method==='GET'){if(!await session(req))return json({error:'login required'},401);const s=(await pool.query("SELECT COUNT(*) total, SUM(CASE WHEN activated_at IS NULL THEN 1 ELSE 0 END) unused, SUM(CASE WHEN activated_at IS NOT NULL AND activated_at > $1 THEN 1 ELSE 0 END) active, SUM(CASE WHEN activated_at IS NOT NULL AND activated_at <= $1 THEN 1 ELSE 0 END) expired FROM license_keys",[new Date(Date.now()-30*day).toISOString()])).rows[0];const p=await pool.query('SELECT * FROM patches');return json({keys:{total:Number(s.total||0),unused:Number(s.unused||0),active:Number(s.active||0),expired:Number(s.expired||0)},patches:p.rows.map(x=>({...x,enabled:!!x.enabled}))})}
if(req.method!=='POST')return json({error:'not found'},404);let data;try{data=JSON.parse(await readBody(req));if(!data||typeof data!=='object'||Array.isArray(data))throw Error()}catch{return json({error:'invalid JSON'},400)}

// --- SENSI OG admin API (revocar / tiempo / registrar) ---
if(path==='/api/og/status'&&req.method==='POST'){
  if(typeof data.key!=='string'||data.key.split('-').length!==5)return json({error:'invalid_key'},400);
  const r=await pool.query('SELECT revoked,force_expires_at FROM license_keys WHERE key=$1',[data.key]);
  const row=r.rows[0];
  if(!row)return json({ok:true,registered:false,revoked:false});
  return json({ok:true,registered:true,revoked:!!row.revoked,force_expires_at:row.force_expires_at||null});
}
if(path==='/api/og/revoke'&&req.method==='POST'){
  if(!process.env.ADMIN_KEY||data.admin_key!==process.env.ADMIN_KEY)return json({error:'forbidden'},403);
  if(typeof data.key!=='string'||data.key.split('-').length!==5)return json({error:'invalid_key'},400);
  await pool.query('INSERT INTO license_keys(key,revoked) VALUES($1,TRUE) ON CONFLICT(key) DO UPDATE SET revoked=TRUE',[data.key]);
  return json({ok:true,revoked:data.key});
}
if(path==='/api/og/revoke-all'&&req.method==='POST'){
  if(!process.env.ADMIN_KEY||data.admin_key!==process.env.ADMIN_KEY)return json({error:'forbidden'},403);
  const r=await pool.query(`UPDATE license_keys SET revoked=TRUE WHERE key LIKE '%-%-%-%-%'`);
  return json({ok:true,count:r.rowCount||0});
}
if(path==='/api/og/delete'&&req.method==='POST'){
  if(!process.env.ADMIN_KEY||data.admin_key!==process.env.ADMIN_KEY)return json({error:'forbidden'},403);
  if(typeof data.key!=='string'||data.key.split('-').length!==5)return json({error:'invalid_key'},400);
  await pool.query('INSERT INTO license_keys(key,revoked) VALUES($1,TRUE) ON CONFLICT(key) DO UPDATE SET revoked=TRUE',[data.key]);
  return json({ok:true,deleted:data.key});
}
if(path==='/api/og/set-expiry'&&req.method==='POST'){
  if(!process.env.ADMIN_KEY||data.admin_key!==process.env.ADMIN_KEY)return json({error:'forbidden'},403);
  if(typeof data.key!=='string'||data.key.split('-').length!==5)return json({error:'invalid_key'},400);
  let expMs=Number(data.expires_at_ms);
  if(!Number.isFinite(expMs)) return json({error:'invalid_expiry'},400);
  if(expMs < Date.now()+5000) expMs=Date.now()+5000;
  await pool.query(
    `INSERT INTO license_keys(key, revoked, force_expires_at) VALUES($1,FALSE,$2)
     ON CONFLICT(key) DO UPDATE SET force_expires_at=$2, revoked=FALSE`,
    [data.key, Math.floor(expMs)]
  );
  return json({ok:true,key:data.key,expires_at:new Date(expMs).toISOString(),expires_at_ms:expMs});
}
if(path==='/api/og/register'&&req.method==='POST'){
  if(!process.env.ADMIN_KEY||data.admin_key!==process.env.ADMIN_KEY)return json({error:'forbidden'},403);
  if(typeof data.key!=='string'||data.key.split('-').length!==5)return json({error:'invalid_key'},400);
  const pv=validatePortableOG(data.key);
  if(!pv||pv.error)return json({error:(pv&&pv.error)||'invalid_key'},400);
  const expMs=new Date(pv.expires_at).getTime();
  await pool.query(
    `INSERT INTO license_keys(key, revoked, max_devices, force_expires_at, duration_ms, is_permanent)
     VALUES($1,FALSE,$2,$3,$4,FALSE)
     ON CONFLICT(key) DO UPDATE SET revoked=FALSE, force_expires_at=$3, max_devices=$2`,
    [data.key, pv.max_devices||1, expMs, Math.max(1, expMs-Date.now())]
  );
  return json({ok:true,key:data.key,expires_at:pv.expires_at});
}

if(path==='/admin/login'){if(!process.env.ADMIN_KEY||data.key!==process.env.ADMIN_KEY)return json({error:'clave incorrecta'},403);const token=crypto.randomUUID()+crypto.randomUUID();await pool.query('INSERT INTO sessions(token_hash,expires_at) VALUES($1,$2)',[await digest(token),Date.now()+3600000]);return json({ok:true},200,{'Set-Cookie':`panther_session=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=3600`})}
if(path==='/admin/logout'){const token=/panther_session=([^;]+)/.exec(req.headers.cookie||'')?.[1];if(token)await pool.query('DELETE FROM sessions WHERE token_hash=$1',[await digest(token)]);return json({ok:true},200,{'Set-Cookie':'panther_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0'})}
if(path.startsWith('/admin/')){if(!await session(req))return json({error:'login required'},401);if(req.headers.origin&&req.headers.origin!==u.origin)return json({error:'origin mismatch'},403);if(path==='/admin/generate-keys'){const n=data.count;if(!Number.isInteger(n)||n<1||n>10000)return json({error:'Cantidad entre 1 y 10000'},400);const durationHours=Number(data.duration_hours||720),maxDevices=Number(data.max_devices||1);if(!Number.isFinite(durationHours)||durationHours<1||durationHours>87600||!Number.isInteger(maxDevices)||maxDevices<1||maxDevices>50)return json({error:'Duración o dispositivos inválidos'},400);const keys=await makeKeys(n,durationHours*3600000,maxDevices);return json({keys,count:keys.length})}if(path==='/admin/keys'){const r=await pool.query('SELECT key,created_at,activated_at,duration_ms,max_devices,devices,revoked FROM (SELECT key,activated_at,duration_ms,max_devices,devices,revoked,NULL::text AS created_at FROM license_keys) k ORDER BY key DESC LIMIT 500');return json({keys:r.rows})}if(path==='/admin/revoke-key'){const r=await pool.query('UPDATE license_keys SET revoked=TRUE WHERE key=$1',[data.key]);return r.rowCount?json({ok:true}):json({error:'key not found'},404)}if(path==='/admin/revoke-all'){await pool.query('UPDATE license_keys SET revoked=TRUE');return json({ok:true})}if(path==='/admin/reset-key'){const r=await pool.query('UPDATE license_keys SET device=NULL,activated_at=NULL WHERE key=$1',[data.key]);return r.rowCount?json({ok:true}):json({error:'key not found'},404)}if(path==='/admin/patches'){if(!Array.isArray(data.patches)||data.patches.length>100)return json({error:'invalid patches'},400);const ids=new Set();for(const p of data.patches){if(!p||typeof p.id!=='string'||!/^[a-zA-Z0-9_-]{1,64}$/.test(p.id)||ids.has(p.id)||typeof p.name!=='string'||p.name.length<1||p.name.length>100||typeof p.description!=='string'||p.description.length>500||typeof p.enabled!=='boolean')return json({error:'invalid patch'},400);ids.add(p.id)}const c=await pool.connect();try{await c.query('BEGIN');await c.query('DELETE FROM patches');for(const p of data.patches)await c.query('INSERT INTO patches(id,name,description,enabled) VALUES($1,$2,$3,$4)',[p.id,p.name,p.description,p.enabled?1:0]);await c.query('COMMIT')}catch(e){await c.query('ROLLBACK');throw e}finally{c.release()}return json({ok:true})}return json({error:'not found'},404)}
if(['/api/activate','/api/patches'].includes(path)||/^\/api\/patches\/.+\/download$/.test(path)){if(typeof data.key!=='string'||typeof data.device_id!=='string'||data.device_id.length<8||data.device_id.length>128)return json({error:'invalid_request'},400);
// Portable SENSI JPF keys — límite de dispositivos + revocación obligatorios
if(typeof data.key==='string'&&data.key.split('-').length===5){
  const pv=validatePortableOG(data.key);
  if(!pv||pv.error)return json({error:(pv&&pv.error)||'invalid_key'},403);
  if(typeof data.device_id!=='string'||!data.device_id)return json({error:'invalid_request'},400);
  const now=new Date().toISOString();
  const maxDev=Math.max(1, Math.min(50, Number(pv.max_devices)||1));
  const dur=Math.max(1, new Date(pv.expires_at).getTime()-Date.now());
  // Crear fila si no existe (no pisa revoked ni devices existentes)
  await pool.query(
    `INSERT INTO license_keys(key, activated_at, devices, max_devices, duration_ms, revoked)
     VALUES($1,$2,'[]'::jsonb,$3,$4,FALSE)
     ON CONFLICT(key) DO NOTHING`,
    [data.key, now, maxDev, dur]
  );
  // Asegurar max_devices de la key
  await pool.query(`UPDATE license_keys SET max_devices=$2 WHERE key=$1 AND revoked=FALSE`,[data.key,maxDev]);
  const r0=await pool.query('SELECT devices,max_devices,revoked,force_expires_at FROM license_keys WHERE key=$1',[data.key]);
  const rec0=r0.rows[0];
  if(!rec0) return json({error:'invalid_key'},403);
  if(rec0.revoked) return json({error:'revoked'},403);
  let devices=rec0.devices;
  if(typeof devices==='string'){try{devices=JSON.parse(devices);}catch(e){devices=[];}}
  if(!Array.isArray(devices)) devices=[];
  const hasDevice=devices.includes(data.device_id);
  if(!hasDevice){
    if(devices.length >= Number(rec0.max_devices||maxDev)){
      return json({error:'device_mismatch'},403);
    }
    devices.push(data.device_id);
    await pool.query(
      `UPDATE license_keys SET devices=$2::jsonb, activated_at=COALESCE(activated_at,$3), device=COALESCE(device,$4) WHERE key=$1 AND revoked=FALSE`,
      [data.key, JSON.stringify(devices), now, data.device_id]
    );
  }
  const r=await pool.query('SELECT devices,max_devices,revoked,force_expires_at FROM license_keys WHERE key=$1',[data.key]);
  const record=r.rows[0];
  if(!record||record.revoked) return json({error:'revoked'},403);
  let devs=record.devices;
  if(typeof devs==='string'){try{devs=JSON.parse(devs);}catch(e){devs=[];}}
  if(!Array.isArray(devs)) devs=[];
  if(!devs.includes(data.device_id)) return json({error:'device_mismatch'},403);
  const embeddedMs = new Date(pv.expires_at).getTime();
  const forceMs = record.force_expires_at != null ? Number(record.force_expires_at) : null;
  const effectiveMs = (forceMs && Number.isFinite(forceMs)) ? forceMs : embeddedMs;
  if(Date.now() >= effectiveMs) return json({error:'expired'},403);
  if(path==='/api/activate')return json({ok:true,role:'user',menus:['patches'],expires_at:new Date(effectiveMs).toISOString(),expires_at_ms:effectiveMs,permanent:false,max_devices:Number(record.max_devices||maxDev),devices_used:devs.length});
  if(path==='/api/patches'){const p=await pool.query('SELECT id,name,description FROM patches WHERE enabled=1');return json({ok:true,patches:p.rows.map(x=>({...x,version:'1.0',category:'general'}))});}
  return json({error:'patch_download_not_configured'},501);
}
const admin=!!process.env.ADMIN_KEY&&data.key===process.env.ADMIN_KEY;let record=null;if(!admin){const now=new Date().toISOString();await pool.query('UPDATE license_keys SET device=COALESCE(device,$1),activated_at=COALESCE(activated_at,$2),devices=CASE WHEN NOT (devices ? $1) AND jsonb_array_length(devices)<max_devices THEN devices || to_jsonb($1::text) ELSE devices END WHERE key=$3 AND revoked=FALSE AND (devices ? $1 OR jsonb_array_length(devices)<max_devices)',[data.device_id,now,data.key]);const r=await pool.query('SELECT device,activated_at,devices,max_devices,duration_ms,revoked,force_expires_at,is_permanent FROM license_keys WHERE key=$1',[data.key]);record=r.rows[0];if(!record||record.revoked)return json({error:'invalid_key'},403);const devices=record.devices||[];if(!devices.includes(data.device_id))return json({error:'device_mismatch'},403);if(!record.is_permanent&&Date.now()-Date.parse(record.activated_at)>=Number(record.duration_ms||0))return json({error:'expired'},403)}if(path==='/api/activate'){const isPerm=admin||!!(record&&record.is_permanent);const expiry=isPerm?null:new Date(Date.parse(record.activated_at)+Number(record.duration_ms||0)).toISOString();if(!isPerm&&record&&Date.now()-Date.parse(record.activated_at)>=Number(record.duration_ms||0))return json({error:'expired'},403);return json({ok:true,role:admin?'admin':'user',menus:admin?['all']:['patches'],expires_at:expiry,permanent:isPerm})}if(path==='/api/patches'){const p=await pool.query('SELECT id,name,description FROM patches WHERE enabled=1');return json({ok:true,patches:p.rows.map(x=>({...x,version:'1.0',category:'general'}))})}return json({error:'patch_download_not_configured'},501)}return json({error:'not found'},404)}
const server=http.createServer(async(req,res)=>{try{const r=await handle(req);res.writeHead(r.status,{...r.headers});res.end(r.body)}catch(e){console.error(e);const r=json({error:'server error'},500);res.writeHead(r.status,r.headers);res.end(r.body)}});
const port=Number(process.env.PORT||10000);await init();server.listen(port,'0.0.0.0',()=>console.log(`SENSI OG server listening on ${port}`));
